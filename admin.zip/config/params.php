<?php

return [
    'adminEmail' => 'niejinping2014@gmail.com',
    'upload_path' => 'C:/wamp2016_new/www/yii2/upload/',

    'aws_s3_cfg' =>  [
        'region' => 'ap-northeast-1',
        'credentials' => [
            'key' => 'AKIAIXGXRS6IHTVI23QQ',
            'secret' => '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',
        ],
        'version' => 'latest',
        // 'debug'   => true
    ],
    'Bucket' => 'theme.kkk',
];